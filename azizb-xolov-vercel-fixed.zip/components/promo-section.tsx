import { Truck, Clock, CreditCard } from "lucide-react"

export function PromoSection() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-white p-4 rounded-lg flex items-center gap-4">
        <div className="bg-blue-100 p-3 rounded-full">
          <Truck className="h-6 w-6 text-blue-600" />
        </div>
        <div>
          <h3 className="font-bold">Bepul yetkazib berish</h3>
          <p className="text-gray-500 text-sm">Birinchi 5 ta buyurtma uchun</p>
        </div>
      </div>
      <div className="bg-white p-4 rounded-lg flex items-center gap-4">
        <div className="bg-blue-100 p-3 rounded-full">
          <Clock className="h-6 w-6 text-blue-600" />
        </div>
        <div>
          <h3 className="font-bold">Tez yetkazib berish</h3>
          <p className="text-gray-500 text-sm">30 daqiqa ichida</p>
        </div>
      </div>
      <div className="bg-white p-4 rounded-lg flex items-center gap-4">
        <div className="bg-blue-100 p-3 rounded-full">
          <CreditCard className="h-6 w-6 text-blue-600" />
        </div>
        <div>
          <h3 className="font-bold">Qulay to'lov</h3>
          <p className="text-gray-500 text-sm">Naqd va karta orqali</p>
        </div>
      </div>
    </div>
  )
}
