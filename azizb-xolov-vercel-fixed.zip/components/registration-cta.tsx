"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { UserPlus } from "lucide-react"

export function RegistrationCTA() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    // Check if user is logged in
    const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    setIsLoggedIn(loggedIn)
  }, [])

  if (isLoggedIn) {
    return null
  }

  return (
    <section className="py-6 bg-blue-600 text-white">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold mb-1">Ro'yxatdan o'ting va buyurtma bering!</h2>
            <p className="text-blue-100">Ro'yxatdan o'tgan mijozlar uchun maxsus chegirmalar va imtiyozlar</p>
          </div>
          <div className="flex gap-3">
            <Button asChild variant="secondary">
              <Link href="/login">Kirish</Link>
            </Button>
            <Button asChild variant="outline" className="bg-transparent text-white border-white hover:bg-blue-700">
              <Link href="/register">
                <UserPlus className="mr-2 h-4 w-4" />
                Ro'yxatdan o'tish
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
