import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { ProductCatalog } from "@/components/product-catalog"

export default function ProductsPage() {
  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      <div className="flex items-center mb-8">
        <Link href="/" className="flex items-center text-gray-600 hover:text-blue-600">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Asosiy sahifaga qaytish</span>
        </Link>
        <h1 className="text-2xl font-bold ml-auto">Barcha mahsulotlar</h1>
      </div>

      <div className="mb-8">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <Button variant="outline" className="flex items-center justify-center h-12">
            Barchasi
          </Button>
          <Button variant="outline" className="flex items-center justify-center h-12">
            Oziq-ovqat
          </Button>
          <Button variant="outline" className="flex items-center justify-center h-12">
            Dori-darmon
          </Button>
          <Button variant="outline" className="flex items-center justify-center h-12">
            Chakana savdo
          </Button>
          <Button variant="outline" className="flex items-center justify-center h-12">
            Oshxona mahsulotlari
          </Button>
          <Button variant="outline" className="flex items-center justify-center h-12">
            Sovg'alar
          </Button>
        </div>
      </div>

      <ProductCatalog />
    </div>
  )
}
